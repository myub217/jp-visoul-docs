export default {
  onActivate() {
    window.createNewFile && window.createNewFile();
    window.toast("สร้างไฟล์ใหม่แล้ว");
  },
  onDeactivate() {}
};