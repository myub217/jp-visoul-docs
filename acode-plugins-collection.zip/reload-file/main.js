export default {
  onActivate() {
    const editor = editorManager?.editor;
    if (editor) {
      editor.setValue(editor.getValue());
      window.toast("ไฟล์ถูกรีโหลดแล้ว");
    } else {
      window.toast("ไม่พบไฟล์ที่เปิดอยู่");
    }
  },
  onDeactivate() {}
};